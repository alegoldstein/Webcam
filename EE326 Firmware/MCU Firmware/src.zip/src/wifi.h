#ifndef WIFI_H
#define WIFI_H

#include <stdio.h>
#include <stdint.h>
#include <asf.h>
#include <string.h>

// USART
#define WIFI_USART              USART0
#define WIFI_USART_ID           ID_USART0
#define WIFI_USART_IRQn         USART0_IRQn
#define WIFI_USART_BAUDRATE     115200
#define WIFI_USART_CHAR_LENGTH  US_MR_CHRL_8_BIT
#define WIFI_USART_PARITY       US_MR_PAR_NO
#define WIFI_USART_STOP_BITS    US_MR_NBSTOP_1_BIT
#define WIFI_USART_MODE         US_MR_CHMODE_NORMAL

#define PIN_USART0_RXD_IDX      (PIO_PA5_IDX)
#define PIN_USART0_RXD_FLAGS    (PIO_PERIPH_A | PIO_PULLUP)
#define PIN_USART0_TXD_IDX      (PIO_PA6_IDX)
#define PIN_USART0_TXD_FLAGS    (PIO_PERIPH_A | PIO_PULLUP)

// SPI 
#define SPI_MISO_GPIO           (PIO_PA12_IDX)
#define SPI_MISO_FLAGS          (PIO_PERIPH_A | PIO_DEFAULT)
#define SPI_MOSI_GPIO           (PIO_PA13_IDX)
#define SPI_MOSI_FLAGS          (PIO_PERIPH_A | PIO_DEFAULT)
#define SPI_SPCK_GPIO           (PIO_PA14_IDX)
#define SPI_SPCK_FLAGS          (PIO_PERIPH_A | PIO_DEFAULT)
#define SPI_NPCS0_GPIO          (PIO_PA11_IDX)
#define SPI_NPCS0_FLAGS         (PIO_PERIPH_A | PIO_DEFAULT)

#define SPI_CHIP_SEL            0
#define SPI_CHIP_PCS            spi_get_pcs(SPI_CHIP_SEL)
#define SPI_CLK_POLARITY        0
#define SPI_CLK_PHASE           0

// ESP command complete pin 
// NOTE: make sure this doesn't conflict with PIN_VSYNC in conf_board.h
#define ESP_CMD_PIN             PIO_PB1       // moved off PA15 to avoid VSYNC conflict
#define ESP_ATTR                PIO_IT_RISE_EDGE
#define INTERRUPT_PIO           PIOB
#define INTERRUPT_ID            ID_PIOB

// WiFi provisioning button
#define PUSH_BUTTON_PIN_MSK     PIN_PUSHBUTTON_1_MASK
#define PUSH_BUTTON_ATTR        PIN_PUSHBUTTON_1_ATTR

// Receive buffer
#define MAX_INPUT_WIFI          1000
#define ALL_INTERRUPT_MASK      0xffffffff

// Shared variables 
volatile char       input_line_wifi[MAX_INPUT_WIFI];
volatile uint32_t   received_byte_wifi;
volatile bool       new_rx_wifi;
volatile unsigned int input_pos_wifi;
volatile bool       wifi_comm_success;
volatile uint32_t   gs_ul_transfer_index;
volatile uint32_t   gs_ul_transfer_len;

// Function declarations

// USART
void USART0_Handler(void);
void wifi_usart_handler(void);
void process_incoming_byte_wifi(uint8_t in_byte);
void process_data_wifi(void);
void configure_usart(void);

// WiFi commands
void write_wifi_command(char* comm, uint8_t cnt);
void write_image_to_web(void);

// Interrupt handlers
void wifi_command_response_handler(uint32_t ul_id, uint32_t ul_mask);
void wifi_provisioning_handler(uint32_t ul_id, uint32_t ul_mask);

// Pin configuration
void configure_wifi_comm_pin(void);
void configure_wifi_provision_pin(void);

// SPI
void wifi_spi_handler(void);
void configure_spi(void);
void spi_peripheral_initialize(void);
void prepare_spi_transfer(void);

#endif 