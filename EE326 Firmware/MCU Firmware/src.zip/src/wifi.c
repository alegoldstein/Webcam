

//#include <asf.h>
#include "wifi.h"
#include <stdio.h>
#include <stdint.h>
#include "conf_board.h"
#include "conf_clock.h"
#include "camera.h"
int count = 0;

//
//variable + pin definitions
//
#define SPI_CHIP_SEL 0

#define SPI_CLK_POLARITY 0

//buffer memory allocation
uint8_t im_buf[100000];

//variables for wifi command + response
static uint8_t cnt = 10;
char *comm = "test\r\n";
volatile uint32_t wifi_ack = 0;

//pointer to transfer buffer
static uint8_t *gs_puc_transfer_buffer;

volatile uint32_t gs_ul_transfer_len;
volatile uint32_t gs_ul_transfer_index;
volatile uint32_t command_complete_flag = 0;

//USART variable defs
/** Size of the receive buffer used by the PDC, in bytes. */
#define BUFFER_SIZE         100

/** USART PDC transfer type definition. */
#define PDC_TRANSFER        1

/** USART FIFO transfer type definition. */
#define BYTE_TRANSFER       0

/** Max buffer number. */
#define MAX_BUF_NUM         1

/** All interrupt mask. */
#define ALL_INTERRUPT_MASK  0xffffffff

/** Timer counter frequency in Hz. */
#define TC_FREQ             1

/* SPI clock setting (Hz). */
static uint32_t gs_ul_spi_clock = 500000;

#define STRING_EOL    "\r"
#define STRING_HEADER "-- USART Serial Example --\r\n" \
		"-- "BOARD_NAME" --\r\n" \
		"-- Compiled: "__DATE__" "__TIME__" --"STRING_EOL

/** Receive buffer. */
static uint8_t gs_puc_buffer[2][BUFFER_SIZE];

/** Next Receive buffer. */
static uint8_t gs_puc_nextbuffer[2][BUFFER_SIZE];

/** Current bytes in buffer. */
static uint32_t gs_ul_size_buffer = BUFFER_SIZE;

/** Current bytes in next buffer. */
static uint32_t gs_ul_size_nextbuffer = BUFFER_SIZE;

/** Byte mode read buffer. */
static uint32_t gs_ul_read_buffer = 0;

/** Current transfer mode. */
static uint8_t gs_uc_trans_mode = PDC_TRANSFER;

/** Buffer number in use. */
static uint8_t gs_uc_buf_num = 0;

static uint8_t g_uc_transend_flag = 0;

static volatile uint32_t WIFI_PROVISION_FLAG = 0;




////////////////////////////////////////////////////
//handles incoming data from wifi, calls process_incoming_byte_wifi when receives new byte
////////////////////////////////////////////////////
void WIFI_USART_HANDLER(){
uint32_t ul_status;

	/* Read USART status. */
	ul_status = usart_get_status(WIFI_USART);

	/* Receive buffer is full. */
	if (ul_status & US_CSR_RXBUFF) {
		usart_read(WIFI_USART, &received_byte_wifi);
		new_rx_wifi = true;
		process_incoming_byte_wifi((uint8_t)received_byte_wifi);
	}
}

////////////////////////////////////////////////////
//stores all incoming bytes from the ESP (input in_byte) into a buffer
////////////////////////////////////////////////////
void process_incoming_byte_wifi(uint8_t in_byte){
	input_line_wifi[input_pos_wifi++] = in_byte;
}


////////////////////////////////////////////////////
//processes response of the ESP which is held in buffer filled by process_incoming_byte_wifi
//looks for certain responses, such as "SUCCESS" when "test" is sent
////////////////////////////////////////////////////
void process_data_wifi(){
if (strstr(input_line_wifi, "SUCCESS")) {
		command_complete_flag = 1;
	}
}

 ////////////////////////////////////////////////////
//configuration of "command complete" rising edge interrupt
////////////////////////////////////////////////////
void configure_wifi_comm_pin(){
/* Configure PIO clock. */
	pmc_enable_periph_clk(INTERRUPT_ID);

	/* Initialize PIO interrupt handler, see PIO definition in conf_board.h */
	pio_handler_set(INTERRUPT_PIO, INTERRUPT_ID, ESP_CMD_PIN,
			PUSH_BUTTON_ATTR, wifi_command_response_handler);

	/* Enable PIO controller IRQs. */
	NVIC_EnableIRQ((IRQn_Type)INTERRUPT_ID);

	/* Enable PIO interrupt lines. */
	pio_enable_interrupt(INTERRUPT_PIO, ESP_CMD_PIN);

}


////////////////////////////////////////////////////
//handles "command complete" rising edge interrupt coming from the ESP, when triggered process
//response of the esp (not sure what that is yet)
////////////////////////////////////////////////////
void wifi_command_response_handler(uint32_t ul_id, uint32_t ul_mask){
	unused(ul_id);
	unused(ul_mask);
	
	wifi_comm_success = true;
	process_data_wifi();
	for (int jj=0;jj<MAX_INPUT_WIFI;jj++) input_line_wifi[jj] = 0;
	input_pos_wifi = 0;
}


////////////////////////////////////////////////////
//configure usart port to communicate with ESP
////////////////////////////////////////////////////
void configure_usart(){
	gpio_configure_pin(PIN_USART0_RXD_IDX, PIN_USART0_RXD_FLAGS);
	gpio_configure_pin(PIN_USART0_TXD_IDX, PIN_USART0_TXD_FLAGS);
	
	static uint32_t ul_sysclk;
	const sam_usart_opt_t wifi_usart_settings = {
		WIFI_USART_BAUDRATE,
		WIFI_USART_CHAR_LENGTH,
		WIFI_USART_PARITY,
		WIFI_USART_STOP_BITS,
		WIFI_USART_MODE,
		/* This field is only used in IrDA mode. */
		0
	};

	/* Get system clock. */
	ul_sysclk = sysclk_get_cpu_hz();
	
	pmc_enable_periph_clk(WIFI_USART_ID);
	
	usart_init_rs232(WIFI_USART,&wifi_usart_settings,ul_sysclk);

	/* Disable all the interrupts. */
	usart_disable_interrupt(WIFI_USART, ALL_INTERRUPT_MASK);
	
	/* Enable TX & RX function. */
	usart_enable_tx(WIFI_USART);
	usart_enable_rx(WIFI_USART);

	usart_enable_interrupt(WIFI_USART, US_IER_RXRDY);

	/* Configure and enable interrupt of USART. */
	NVIC_EnableIRQ(WIFI_USART_IRQn);
}


////////////////////////////////////////////////////
//writes command (input comm) to ESP, and either gets ack (command complete pin) or waits for timeout
//timeout done by creating global variable counts, which increments and compare to cnt (counts < cnt)
////////////////////////////////////////////////////
void write_wifi_command(char* comm, uint8_t cnt){
	//write command to esp over usart
	while(*comm) {
		usart_write(BOARD_USART, *comm++);
	}

	while (cnt < count && ) {

	}
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*SPI*/

////////////////////////////////////////////////////
//handler for peripheral mode interupts on the SPI bus
//when ESP requests data over SPI, send one byte of the image at a time
////////////////////////////////////////////////////
void wifi_spi_handler(){
uint32_t new_cmd = 0;
	static uint16_t data;
	uint8_t uc_pcs;

	if (spi_read_status(SPI) & SPI_SR_RDRF) {
		spi_read(SPI, &data, &uc_pcs);
		
		if (gs_ul_transfer_len--) {
			spi_write(SPI, gs_ul_transfer_index++, 0, 0);
		}
	}
}


////////////////////////////////////////////////////
//configure SPI ports and interrupts to send data of images to ESP
////////////////////////////////////////////////////
void configure_spi(){
	// uint32_t spi_pins = PIO_PA17A_MISO | PIO_PA18A_MOSI | PIO_PA19A_SPCK | PIO_PA16A_NPCS0;

	// pio_set_peripheral(PIOA, PIO_PERIPH_A, spi_pins);

	// NVIC_EnableIRQ(SPI_IRQn);
	gpio_configure_pin(SPI_MISO_GPIO, SPI_MISO_FLAGS);
	gpio_configure_pin(SPI_MOSI_GPIO, SPI_MOSI_FLAGS);
	gpio_configure_pin(SPI_SPCK_GPIO, SPI_SPCK_FLAGS);
	gpio_configure_pin(SPI_NPCS0_GPIO, SPI_NPCS0_FLAGS);
	
	/* Configure SPI interrupts for slave only. */
	NVIC_DisableIRQ(SPI_IRQn);
	NVIC_ClearPendingIRQ(SPI_IRQn);
	NVIC_SetPriority(SPI_IRQn, 0);
	NVIC_EnableIRQ(SPI_IRQn);
}

////////////////////////////////////////////////////
//initialize SPI port as peripheral (commonly slave)
////////////////////////////////////////////////////
//spi_slave_base is pointer to structure in memory
void spi_peripheral_initialize(){
   	spi_enable_clock(SPI);
	spi_disable(SPI);
	spi_reset(SPI);
	spi_set_slave_mode(SPI);
	spi_disable_mode_fault_detect(SPI);
	spi_set_peripheral_chip_select_value(SPI, SPI_CHIP_PCS);
	spi_set_clock_polarity(SPI, SPI_CHIP_SEL, SPI_CLK_POLARITY);
	spi_set_clock_phase(SPI, SPI_CHIP_SEL, SPI_CLK_PHASE);
	spi_set_bits_per_transfer(SPI, SPI_CHIP_SEL, SPI_CSR_BITS_8_BIT);
	spi_enable_interrupt(SPI, SPI_IER_RDRF);
	spi_enable(SPI);
}

////////////////////////////////////////////////////
//set parameters to prepare for peripheral transfer (also commonly slave)
////////////////////////////////////////////////////
void prepare_spi_transfer(){
   	gs_ul_transfer_len = 100;
	gs_ul_transfer_index = 0;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////
//configuration of button interupt for provisioning mode
////////////////////////////////////////////////////
void configure_wifi_provision_pin(){
/* Configure PIO clock. */
	pmc_enable_periph_clk(INTERRUPT_ID);

	/* Adjust PIO debounce filter using a 10 Hz filter. */
	pio_set_debounce_filter(INTERRUPT_PIO, PUSH_BUTTON_PIN_MSK, 10);

	/* Initialize PIO interrupt handler, see PIO definition in conf_board.h
	**/
	pio_handler_set(INTERRUPT_PIO, INTERRUPT_ID, PUSH_BUTTON_PIN_MSK,
			ESP_ATTR, wifi_provisioning_handler);

	/* Enable PIO controller IRQs. */
	NVIC_EnableIRQ((IRQn_Type)INTERRUPT_ID);

	/* Enable PIO interrupt lines. */
	pio_enable_interrupt(INTERRUPT_PIO, PUSH_BUTTON_PIN_MSK);
}

////////////////////////////////////////////////////
//handler for button pressed to put ESP in provisioning mode, sets flag indicating request
////////////////////////////////////////////////////
void wifi_provisioning_handler(uint32_t ul_id, uint32_t ul_mask){
unused(ul_id);
unused(ul_mask);

WIFI_PROVISION_FLAG = !WIFI_PROVISION_FLAG;
}


////////////////////////////////////////////////////
//write image from MCU to ESP, if image length is 0 then just return
////////////////////////////////////////////////////
void write_image_to_web(void){
	if (image_len != 0){

	}
}
/*writes an image from the SAM4S8B to the ESP32. If the
length of the image is zero (i.e. the image is not valid), return. Otherwise, follow this protocol
(illustrated in Appendix C):
1. Configure the SPI interface to be ready for a transfer by setting its parameters appropriately.
2. Issue the command “image_transfer xxxx”, where xxxx is replaced by the length of the
image you want to transfer.
3. The ESP32 will then set the “command complete” pin low and begin transferring the image
over SPI.
4. After the image is done sending, the ESP32 will set the “command complete” pin high. The
MCU should sense this and then move on.*/


